# Generative and Conversational AI Notebooks

Both notebooks in this repository are designed to run on [Google Colab](https://colab.research.google.com/). Enjoy exploring and experimenting!
